declare namespace NodeJS {
  interface Global {
    moneyCount: number
    iterationDelay: number
    showNegative: boolean
    precision: number
  }
}
